import React from "react";
import { Link, useLocation } from "wouter";
import { 
  Users, 
  Droplet, 
  FileText, 
  AlertTriangle, 
  LayoutDashboard,
  Home,
} from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarProvider,
  SidebarFooter,
} from "@/components/ui/sidebar";

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar className="border-r">
      <SidebarHeader className="py-6 px-4">
        <div className="flex flex-col items-start gap-1">
          <h1 className="text-2xl font-bold tracking-tight text-sidebar-primary-foreground">REGIDESO</h1>
          <p className="text-xs font-medium text-sidebar-primary-foreground/70 uppercase tracking-wider">Gestion des Abonnés</p>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu className="px-2 space-y-1">
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={location === "/dashboard"}>
              <Link href="/dashboard" className="flex items-center gap-3">
                <LayoutDashboard className="h-4 w-4" />
                <span>Tableau de bord</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={location.startsWith("/clients")}>
              <Link href="/clients" className="flex items-center gap-3">
                <Users className="h-4 w-4" />
                <span>Abonnés</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={location.startsWith("/consommations")}>
              <Link href="/consommations" className="flex items-center gap-3">
                <Droplet className="h-4 w-4" />
                <span>Consommations</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={location.startsWith("/factures")}>
              <Link href="/factures" className="flex items-center gap-3">
                <FileText className="h-4 w-4" />
                <span>Factures</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild isActive={location.startsWith("/reclamations")}>
              <Link href="/reclamations" className="flex items-center gap-3">
                <AlertTriangle className="h-4 w-4" />
                <span>Réclamations</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="px-3 py-4 border-t border-sidebar-border">
        <SidebarMenuItem>
          <SidebarMenuButton asChild>
            <Link href="/" data-testid="btn-retour-accueil" className="flex items-center gap-3 text-sidebar-foreground/70 hover:text-sidebar-foreground">
              <Home className="h-4 w-4" />
              <span>Retour à l'accueil</span>
            </Link>
          </SidebarMenuButton>
        </SidebarMenuItem>
        <p className="text-[10px] text-sidebar-foreground/40 mt-3 px-1 leading-relaxed">
          © {new Date().getFullYear()} REGIDESO — Tous droits réservés.<br />
          <span className="text-sidebar-foreground/30">Réalisé par Ngandu Ngandu Jean<br />L3 Informatique de Gestion</span>
        </p>
      </SidebarFooter>
    </Sidebar>
  );
}
