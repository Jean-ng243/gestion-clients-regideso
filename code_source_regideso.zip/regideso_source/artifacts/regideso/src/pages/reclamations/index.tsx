import React, { useState } from "react";
import { Link } from "wouter";
import { useListReclamations, useUpdateReclamation, getListReclamationsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function Reclamations() {
  const [statut, setStatut] = useState<string>("all");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const params: any = {};
  if (statut !== "all") params.statut = statut;

  const { data: reclamations, isLoading } = useListReclamations(params);
  const updateReclamation = useUpdateReclamation();

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ouverte": return "bg-red-500 text-white";
      case "en_cours": return "bg-yellow-500 text-white";
      case "resolue": return "bg-blue-500 text-white";
      case "fermee": return "bg-gray-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const handleStatusChange = (id: number, newStatus: any) => {
    const data: any = { statut: newStatus };
    if (newStatus === "resolue" || newStatus === "fermee") {
      data.dateResolution = new Date().toISOString();
    }
    
    updateReclamation.mutate({ id, data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListReclamationsQueryKey(params) });
        toast({ title: "Statut mis à jour", description: "La réclamation a été mise à jour." });
      },
      onError: () => {
        toast({ title: "Erreur", description: "Impossible de mettre à jour la réclamation.", variant: "destructive" });
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Réclamations</h1>
      </div>
      
      <div className="flex gap-4 items-center">
        <div className="w-48">
          <Select value={statut} onValueChange={setStatut}>
            <SelectTrigger>
              <SelectValue placeholder="Statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les statuts</SelectItem>
              <SelectItem value="ouverte">Ouvertes</SelectItem>
              <SelectItem value="en_cours">En cours</SelectItem>
              <SelectItem value="resolue">Résolues</SelectItem>
              <SelectItem value="fermee">Fermées</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[100px]">Date</TableHead>
              <TableHead>Abonné</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="max-w-[300px]">Description</TableHead>
              <TableHead className="w-[150px]">Statut</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-full" /></TableCell>
                </TableRow>
              ))
            ) : reclamations?.map((reclamation) => (
              <TableRow key={reclamation.id} className="hover:bg-muted/50 transition-colors">
                <TableCell className="text-xs text-muted-foreground">
                  {new Date(reclamation.dateCreation).toLocaleDateString('fr-FR')}
                </TableCell>
                <TableCell>
                  <Link href={`/clients/${reclamation.clientId}`} className="font-medium hover:underline">
                    {reclamation.clientNom} {reclamation.clientPrenom}
                  </Link>
                  <div className="text-xs text-muted-foreground font-mono">{reclamation.numeroAbonnement}</div>
                </TableCell>
                <TableCell className="font-medium capitalize">{reclamation.type}</TableCell>
                <TableCell className="max-w-[300px] truncate" title={reclamation.description}>
                  {reclamation.description}
                </TableCell>
                <TableCell>
                  <Select 
                    value={reclamation.statut} 
                    onValueChange={(val) => handleStatusChange(reclamation.id, val)}
                  >
                    <SelectTrigger className={`h-8 border-none text-white ${getStatusColor(reclamation.statut)}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ouverte">Ouverte</SelectItem>
                      <SelectItem value="en_cours">En cours</SelectItem>
                      <SelectItem value="resolue">Résolue</SelectItem>
                      <SelectItem value="fermee">Fermée</SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>
              </TableRow>
            ))}
            {reclamations?.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">Aucune réclamation trouvée.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
