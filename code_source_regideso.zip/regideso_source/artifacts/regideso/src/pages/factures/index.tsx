import React, { useState } from "react";
import { Link } from "wouter";
import { useListFactures, useUpdateFacture, getListFacturesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Factures() {
  const [statut, setStatut] = useState<string>("all");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const params: any = {};
  if (statut !== "all") params.statut = statut;

  const { data: factures, isLoading } = useListFactures(params);
  const updateFacture = useUpdateFacture();

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case "payee": return "bg-green-500 text-white";
      case "en_attente": return "bg-yellow-500 text-white";
      case "impayee": return "bg-red-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const handleMarkAsPaid = (id: number) => {
    updateFacture.mutate({ id, data: { statutPaiement: "payee", datePaiement: new Date().toISOString() } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFacturesQueryKey(params) });
        toast({ title: "Facture réglée", description: "Le paiement a été enregistré avec succès." });
      },
      onError: () => {
        toast({ title: "Erreur", description: "Impossible d'enregistrer le paiement.", variant: "destructive" });
      }
    });
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Factures</h1>
      </div>
      
      <div className="flex gap-4 items-center">
        <div className="w-48">
          <Select value={statut} onValueChange={setStatut}>
            <SelectTrigger>
              <SelectValue placeholder="Statut" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les statuts</SelectItem>
              <SelectItem value="payee">Payées</SelectItem>
              <SelectItem value="en_attente">En attente</SelectItem>
              <SelectItem value="impayee">Impayées</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>N° Facture</TableHead>
              <TableHead>Abonné</TableHead>
              <TableHead>Émission</TableHead>
              <TableHead>Statut</TableHead>
              <TableHead className="text-right">Montant (FC)</TableHead>
              <TableHead className="w-[100px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16 ml-auto" /></TableCell>
                  <TableCell></TableCell>
                </TableRow>
              ))
            ) : factures?.map((facture) => (
              <TableRow key={facture.id} className="hover:bg-muted/50 transition-colors">
                <TableCell className="font-mono text-xs font-medium">F-{facture.id.toString().padStart(6, '0')}</TableCell>
                <TableCell>
                  <Link href={`/clients/${facture.clientId}`} className="hover:underline font-medium">
                    {facture.clientNom} {facture.clientPrenom}
                  </Link>
                  <div className="text-xs text-muted-foreground font-mono">{facture.numeroAbonnement}</div>
                </TableCell>
                <TableCell>{new Date(facture.dateEmission).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell>
                  <Badge className={`${getPaymentStatusColor(facture.statutPaiement)} border-none text-[10px]`}>
                    {facture.statutPaiement.replace('_', ' ').toUpperCase()}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-bold">{facture.montant.toLocaleString()}</TableCell>
                <TableCell>
                  {facture.statutPaiement !== "payee" && (
                    <Button variant="ghost" size="sm" onClick={() => handleMarkAsPaid(facture.id)}>
                      <CheckCircle className="h-4 w-4 mr-1 text-green-600" />
                      Payer
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
            {factures?.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">Aucune facture trouvée.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
