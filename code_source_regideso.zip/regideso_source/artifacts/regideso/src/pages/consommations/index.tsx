import React, { useState } from "react";
import { Link } from "wouter";
import { useListConsommations, useCreateConsommation, getListConsommationsQueryKey, useListClients } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  clientId: z.coerce.number().min(1, "Veuillez sélectionner un abonné"),
  mois: z.coerce.number().min(1).max(12),
  annee: z.coerce.number().min(2000).max(2100),
  m3Consommes: z.coerce.number().min(0, "Le volume doit être positif"),
  dateReleve: z.string().min(1, "La date de relevé est requise"),
});

type FormValues = z.infer<typeof formSchema>;

export default function Consommations() {
  const [mois, setMois] = useState<string>("all");
  const [annee, setAnnee] = useState<string>(new Date().getFullYear().toString());
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const params: any = {};
  if (mois !== "all") params.mois = Number(mois);
  if (annee !== "all") params.annee = Number(annee);

  const { data: consommations, isLoading } = useListConsommations(params);
  const { data: clients } = useListClients({ statut: 'actif' });
  const createConsommation = useCreateConsommation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      clientId: 0,
      mois: new Date().getMonth() + 1,
      annee: new Date().getFullYear(),
      m3Consommes: 0,
      dateReleve: new Date().toISOString().split('T')[0],
    },
  });

  const onSubmit = (values: FormValues) => {
    createConsommation.mutate(
      { data: {
        ...values,
        dateReleve: new Date(values.dateReleve).toISOString()
      } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListConsommationsQueryKey() });
          setIsDialogOpen(false);
          form.reset();
          toast({
            title: "Relevé enregistré",
            description: "Le relevé de consommation a été enregistré avec succès.",
          });
        },
        onError: () => {
          toast({
            title: "Erreur",
            description: "Impossible d'enregistrer le relevé.",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Relevés de Consommation</h1>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nouveau Relevé
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Enregistrer un relevé</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="clientId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Abonné</FormLabel>
                      <Select onValueChange={(val) => field.onChange(Number(val))} value={field.value ? field.value.toString() : undefined}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionner un abonné" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {clients?.map(c => (
                            <SelectItem key={c.id} value={c.id.toString()}>
                              {c.numeroAbonnement} - {c.nom} {c.prenom}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="mois"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mois</FormLabel>
                        <FormControl>
                          <Input type="number" min={1} max={12} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="annee"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Année</FormLabel>
                        <FormControl>
                          <Input type="number" min={2000} max={2100} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="m3Consommes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Volume (m³)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="dateReleve"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date de relevé</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <Button type="submit" className="w-full" disabled={createConsommation.isPending}>
                  {createConsommation.isPending ? "Enregistrement..." : "Enregistrer"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="flex gap-4 items-center">
        <div className="w-40">
          <Select value={mois} onValueChange={setMois}>
            <SelectTrigger>
              <SelectValue placeholder="Mois" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les mois</SelectItem>
              {Array.from({ length: 12 }).map((_, i) => (
                <SelectItem key={i + 1} value={(i + 1).toString()}>
                  {new Date(0, i).toLocaleString('fr', { month: 'long' })}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-32">
          <Select value={annee} onValueChange={setAnnee}>
            <SelectTrigger>
              <SelectValue placeholder="Année" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Toutes</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Abonné</TableHead>
              <TableHead>Numéro</TableHead>
              <TableHead>Période</TableHead>
              <TableHead>Date de relevé</TableHead>
              <TableHead className="text-right">Volume (m³)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : consommations?.map((conso) => (
              <TableRow key={conso.id} className="hover:bg-muted/50 transition-colors">
                <TableCell className="font-medium">
                  <Link href={`/clients/${conso.clientId}`} className="hover:underline">
                    {conso.clientNom} {conso.clientPrenom}
                  </Link>
                </TableCell>
                <TableCell className="font-mono text-xs text-muted-foreground">{conso.numeroAbonnement}</TableCell>
                <TableCell>{conso.mois.toString().padStart(2, '0')}/{conso.annee}</TableCell>
                <TableCell>{new Date(conso.dateReleve).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell className="text-right font-medium">{conso.m3Consommes}</TableCell>
              </TableRow>
            ))}
            {consommations?.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">Aucun relevé trouvé pour cette période.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
