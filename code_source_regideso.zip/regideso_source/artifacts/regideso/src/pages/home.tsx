import { Link } from "wouter";
import { Droplet, Users, FileText, AlertTriangle, BarChart3, ArrowRight, Shield, Zap, Database } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: "linear-gradient(135deg, #0f2942 0%, #1a3a5c 50%, #0f2942 100%)" }}>
      <header className="px-8 py-5 flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-md bg-sky-400/20 flex items-center justify-center">
            <Droplet className="h-5 w-5 text-sky-300" />
          </div>
          <div>
            <p className="text-white font-bold text-lg leading-none tracking-tight">REGIDESO</p>
            <p className="text-sky-300/70 text-[10px] uppercase tracking-widest leading-none mt-0.5">Régie de Distribution de l'Eau</p>
          </div>
        </div>
        <Link href="/dashboard">
          <button
            data-testid="btn-acces-systeme-header"
            className="flex items-center gap-2 bg-sky-500 hover:bg-sky-400 text-white text-sm font-semibold px-5 py-2.5 rounded-md transition-all duration-200 shadow-lg shadow-sky-900/30"
          >
            Accéder au système
            <ArrowRight className="h-4 w-4" />
          </button>
        </Link>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center px-6 py-16 text-center">
        <div className="mb-5 inline-flex items-center gap-2 bg-sky-400/10 border border-sky-400/20 text-sky-300 text-xs font-semibold px-4 py-1.5 rounded-full uppercase tracking-widest">
          Plateforme officielle de gestion
        </div>

        <h1 className="text-5xl md:text-6xl font-extrabold text-white leading-tight max-w-3xl mb-6">
          Gestion des Abonnés
          <span className="block text-sky-400 mt-1">REGIDESO</span>
        </h1>

        <p className="text-slate-300 text-lg max-w-2xl mb-6 leading-relaxed">
          Plateforme centralisée pour la gestion des clients, le suivi des consommations,
          la facturation et le traitement des réclamations de la Régie de Distribution de l'Eau.
        </p>

        <div className="bg-white/5 border border-white/10 rounded-xl px-6 py-4 max-w-xl w-full mb-10 text-left">
          <p className="text-sky-300 text-xs font-semibold uppercase tracking-widest mb-2">Projet tutoré — Fin de cycle de Licence</p>
          <p className="text-slate-200 text-sm leading-relaxed">
            Ce système a été conçu et réalisé par{" "}
            <span className="font-semibold text-white">Ngandu Ngandu Jean</span>,
            étudiant en <span className="font-semibold text-white">L3 Informatique de Gestion</span>,
            dans le cadre de son projet tutoré pour l'obtention de son diplôme de Licence.
          </p>
        </div>

        <Link href="/dashboard">
          <button
            data-testid="btn-acces-tableau-de-bord"
            className="group flex items-center gap-3 bg-sky-500 hover:bg-sky-400 text-white font-bold px-8 py-4 rounded-lg text-base transition-all duration-200 shadow-2xl shadow-sky-900/40 mb-16"
          >
            <BarChart3 className="h-5 w-5" />
            Accéder au Tableau de Bord
            <ArrowRight className="h-5 w-5 transition-transform duration-200 group-hover:translate-x-1" />
          </button>
        </Link>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl w-full mb-16">
          {[
            { icon: Users, label: "Abonnés", desc: "Gestion des clients et enregistrements" },
            { icon: Droplet, label: "Consommations", desc: "Relevés de compteurs mensuels" },
            { icon: FileText, label: "Factures", desc: "Suivi des paiements et impayés" },
            { icon: AlertTriangle, label: "Réclamations", desc: "Traitement des plaintes abonnés" },
          ].map(({ icon: Icon, label, desc }) => (
            <div
              key={label}
              className="bg-white/5 border border-white/10 rounded-xl p-5 text-left hover:bg-white/8 transition-colors duration-200"
            >
              <div className="w-9 h-9 rounded-md bg-sky-400/15 flex items-center justify-center mb-3">
                <Icon className="h-4 w-4 text-sky-400" />
              </div>
              <p className="text-white font-semibold text-sm mb-1">{label}</p>
              <p className="text-slate-400 text-xs leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        <div className="flex flex-col md:flex-row items-center gap-8 text-slate-400 text-sm">
          {[
            { icon: Shield, text: "Données sécurisées" },
            { icon: Zap, text: "Accès en temps réel" },
            { icon: Database, text: "Base de données centralisée" },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-2">
              <Icon className="h-4 w-4 text-sky-400/60" />
              <span>{text}</span>
            </div>
          ))}
        </div>
      </main>

      <footer className="px-8 py-5 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-2 text-slate-500 text-xs">
        <p>© {new Date().getFullYear()} REGIDESO — Régie de Distribution de l'Eau. Tous droits réservés.</p>
        <p className="text-center md:text-right">
          Réalisé par <span className="text-slate-400 font-medium">Ngandu Ngandu Jean</span> — L3 Informatique de Gestion &nbsp;|&nbsp; République Démocratique du Congo
        </p>
      </footer>
    </div>
  );
}
