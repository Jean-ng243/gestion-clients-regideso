import { Router, type IRouter } from "express";
import healthRouter from "./health";
import clientsRouter from "./clients";
import consommationsRouter from "./consommations";
import facturesRouter from "./factures";
import reclamationsRouter from "./reclamations";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(clientsRouter);
router.use(consommationsRouter);
router.use(facturesRouter);
router.use(reclamationsRouter);
router.use(dashboardRouter);

export default router;
