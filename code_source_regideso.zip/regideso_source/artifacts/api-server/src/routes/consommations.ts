import { Router } from "express";
import { eq, and } from "drizzle-orm";
import { db, clientsTable, consommationsTable } from "@workspace/db";
import {
  ListConsommationsQueryParams,
  CreateConsommationBody,
  GetClientConsommationsParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/consommations", async (req, res) => {
  const parsed = ListConsommationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Paramètres invalides" });
  }
  const { mois, annee } = parsed.data;

  const conditions = [];
  if (mois !== undefined) conditions.push(eq(consommationsTable.mois, mois));
  if (annee !== undefined) conditions.push(eq(consommationsTable.annee, annee));

  const rows =
    conditions.length > 0
      ? await db
          .select({
            id: consommationsTable.id,
            clientId: consommationsTable.clientId,
            clientNom: clientsTable.nom,
            clientPrenom: clientsTable.prenom,
            numeroAbonnement: clientsTable.numeroAbonnement,
            mois: consommationsTable.mois,
            annee: consommationsTable.annee,
            m3Consommes: consommationsTable.m3Consommes,
            dateReleve: consommationsTable.dateReleve,
          })
          .from(consommationsTable)
          .leftJoin(clientsTable, eq(consommationsTable.clientId, clientsTable.id))
          .where(and(...conditions))
      : await db
          .select({
            id: consommationsTable.id,
            clientId: consommationsTable.clientId,
            clientNom: clientsTable.nom,
            clientPrenom: clientsTable.prenom,
            numeroAbonnement: clientsTable.numeroAbonnement,
            mois: consommationsTable.mois,
            annee: consommationsTable.annee,
            m3Consommes: consommationsTable.m3Consommes,
            dateReleve: consommationsTable.dateReleve,
          })
          .from(consommationsTable)
          .leftJoin(clientsTable, eq(consommationsTable.clientId, clientsTable.id));

  return res.json(
    rows.map((r) => ({
      ...r,
      m3Consommes: Number(r.m3Consommes),
      dateReleve: r.dateReleve.toISOString(),
    }))
  );
});

router.post("/consommations", async (req, res) => {
  const parsed = CreateConsommationBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Données invalides" });
  }

  const { clientId, mois, annee, m3Consommes, dateReleve } = parsed.data;

  const inserted = await db
    .insert(consommationsTable)
    .values({
      clientId,
      mois,
      annee,
      m3Consommes: String(m3Consommes),
      dateReleve: new Date(dateReleve),
    })
    .returning();

  const row = inserted[0];
  const client = await db
    .select()
    .from(clientsTable)
    .where(eq(clientsTable.id, row.clientId))
    .limit(1);

  return res.status(201).json({
    ...row,
    clientNom: client[0]?.nom ?? null,
    clientPrenom: client[0]?.prenom ?? null,
    numeroAbonnement: client[0]?.numeroAbonnement ?? null,
    m3Consommes: Number(row.m3Consommes),
    dateReleve: row.dateReleve.toISOString(),
  });
});

router.get("/clients/:id/consommations", async (req, res) => {
  const parsed = GetClientConsommationsParams.safeParse(req.params);
  if (!parsed.success) {
    return res.status(400).json({ error: "ID invalide" });
  }

  const rows = await db
    .select({
      id: consommationsTable.id,
      clientId: consommationsTable.clientId,
      clientNom: clientsTable.nom,
      clientPrenom: clientsTable.prenom,
      numeroAbonnement: clientsTable.numeroAbonnement,
      mois: consommationsTable.mois,
      annee: consommationsTable.annee,
      m3Consommes: consommationsTable.m3Consommes,
      dateReleve: consommationsTable.dateReleve,
    })
    .from(consommationsTable)
    .leftJoin(clientsTable, eq(consommationsTable.clientId, clientsTable.id))
    .where(eq(consommationsTable.clientId, parsed.data.id));

  return res.json(
    rows.map((r) => ({
      ...r,
      m3Consommes: Number(r.m3Consommes),
      dateReleve: r.dateReleve.toISOString(),
    }))
  );
});

export default router;
