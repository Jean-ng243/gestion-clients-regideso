import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, clientsTable, facturesTable } from "@workspace/db";
import {
  ListFacturesQueryParams,
  CreateFactureBody,
  UpdateFactureParams,
  UpdateFactureBody,
  GetClientFacturesParams,
} from "@workspace/api-zod";

const router = Router();

function mapFacture(r: {
  id: number;
  clientId: number;
  clientNom: string | null;
  clientPrenom: string | null;
  numeroAbonnement: string | null;
  consommationId: number | null;
  montant: string;
  statutPaiement: "payee" | "impayee" | "en_attente";
  dateEmission: Date;
  dateEcheance: Date | null;
  datePaiement: Date | null;
}) {
  return {
    ...r,
    montant: Number(r.montant),
    dateEmission: r.dateEmission.toISOString(),
    dateEcheance: r.dateEcheance?.toISOString() ?? null,
    datePaiement: r.datePaiement?.toISOString() ?? null,
  };
}

router.get("/factures", async (req, res) => {
  const parsed = ListFacturesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Paramètres invalides" });
  }

  const baseQuery = db
    .select({
      id: facturesTable.id,
      clientId: facturesTable.clientId,
      clientNom: clientsTable.nom,
      clientPrenom: clientsTable.prenom,
      numeroAbonnement: clientsTable.numeroAbonnement,
      consommationId: facturesTable.consommationId,
      montant: facturesTable.montant,
      statutPaiement: facturesTable.statutPaiement,
      dateEmission: facturesTable.dateEmission,
      dateEcheance: facturesTable.dateEcheance,
      datePaiement: facturesTable.datePaiement,
    })
    .from(facturesTable)
    .leftJoin(clientsTable, eq(facturesTable.clientId, clientsTable.id));

  const rows = parsed.data.statut
    ? await baseQuery.where(
        eq(facturesTable.statutPaiement, parsed.data.statut as "payee" | "impayee" | "en_attente")
      )
    : await baseQuery;

  return res.json(rows.map(mapFacture));
});

router.post("/factures", async (req, res) => {
  const parsed = CreateFactureBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Données invalides" });
  }

  const { clientId, consommationId, montant, statutPaiement, dateEmission, dateEcheance } = parsed.data;

  const inserted = await db
    .insert(facturesTable)
    .values({
      clientId,
      consommationId: consommationId ?? null,
      montant: String(montant),
      statutPaiement: (statutPaiement as "payee" | "impayee" | "en_attente") ?? "en_attente",
      dateEmission: new Date(dateEmission),
      dateEcheance: dateEcheance ? new Date(dateEcheance) : null,
    })
    .returning();

  const row = inserted[0];
  const client = await db
    .select()
    .from(clientsTable)
    .where(eq(clientsTable.id, row.clientId))
    .limit(1);

  return res.status(201).json(
    mapFacture({
      ...row,
      clientNom: client[0]?.nom ?? null,
      clientPrenom: client[0]?.prenom ?? null,
      numeroAbonnement: client[0]?.numeroAbonnement ?? null,
    })
  );
});

router.patch("/factures/:id", async (req, res) => {
  const paramsParsed = UpdateFactureParams.safeParse(req.params);
  const bodyParsed = UpdateFactureBody.safeParse(req.body);

  if (!paramsParsed.success || !bodyParsed.success) {
    return res.status(400).json({ error: "Données invalides" });
  }

  const updateData: Record<string, unknown> = {};
  if (bodyParsed.data.montant !== undefined) updateData.montant = String(bodyParsed.data.montant);
  if (bodyParsed.data.statutPaiement !== undefined) updateData.statutPaiement = bodyParsed.data.statutPaiement;
  if (bodyParsed.data.datePaiement !== undefined) updateData.datePaiement = new Date(bodyParsed.data.datePaiement);

  const updated = await db
    .update(facturesTable)
    .set(updateData)
    .where(eq(facturesTable.id, paramsParsed.data.id))
    .returning();

  if (updated.length === 0) {
    return res.status(404).json({ error: "Facture non trouvée" });
  }

  const row = updated[0];
  const client = await db
    .select()
    .from(clientsTable)
    .where(eq(clientsTable.id, row.clientId))
    .limit(1);

  return res.json(
    mapFacture({
      ...row,
      clientNom: client[0]?.nom ?? null,
      clientPrenom: client[0]?.prenom ?? null,
      numeroAbonnement: client[0]?.numeroAbonnement ?? null,
    })
  );
});

router.get("/clients/:id/factures", async (req, res) => {
  const parsed = GetClientFacturesParams.safeParse(req.params);
  if (!parsed.success) {
    return res.status(400).json({ error: "ID invalide" });
  }

  const rows = await db
    .select({
      id: facturesTable.id,
      clientId: facturesTable.clientId,
      clientNom: clientsTable.nom,
      clientPrenom: clientsTable.prenom,
      numeroAbonnement: clientsTable.numeroAbonnement,
      consommationId: facturesTable.consommationId,
      montant: facturesTable.montant,
      statutPaiement: facturesTable.statutPaiement,
      dateEmission: facturesTable.dateEmission,
      dateEcheance: facturesTable.dateEcheance,
      datePaiement: facturesTable.datePaiement,
    })
    .from(facturesTable)
    .leftJoin(clientsTable, eq(facturesTable.clientId, clientsTable.id))
    .where(eq(facturesTable.clientId, parsed.data.id));

  return res.json(rows.map(mapFacture));
});

export default router;
