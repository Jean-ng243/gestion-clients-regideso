import { Router } from "express";
import { eq } from "drizzle-orm";
import { db, clientsTable, reclamationsTable } from "@workspace/db";
import {
  ListReclamationsQueryParams,
  CreateReclamationBody,
  UpdateReclamationParams,
  UpdateReclamationBody,
} from "@workspace/api-zod";

const router = Router();

function mapReclamation(r: {
  id: number;
  clientId: number;
  clientNom: string | null;
  clientPrenom: string | null;
  numeroAbonnement: string | null;
  type: "fuite" | "facturation" | "coupure" | "qualite" | "autre";
  description: string;
  statut: "ouverte" | "en_cours" | "resolue" | "fermee";
  dateCreation: Date;
  dateResolution: Date | null;
}) {
  return {
    ...r,
    dateCreation: r.dateCreation.toISOString(),
    dateResolution: r.dateResolution?.toISOString() ?? null,
  };
}

router.get("/reclamations", async (req, res) => {
  const parsed = ListReclamationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Paramètres invalides" });
  }

  const baseQuery = db
    .select({
      id: reclamationsTable.id,
      clientId: reclamationsTable.clientId,
      clientNom: clientsTable.nom,
      clientPrenom: clientsTable.prenom,
      numeroAbonnement: clientsTable.numeroAbonnement,
      type: reclamationsTable.type,
      description: reclamationsTable.description,
      statut: reclamationsTable.statut,
      dateCreation: reclamationsTable.dateCreation,
      dateResolution: reclamationsTable.dateResolution,
    })
    .from(reclamationsTable)
    .leftJoin(clientsTable, eq(reclamationsTable.clientId, clientsTable.id));

  const rows = parsed.data.statut
    ? await baseQuery.where(
        eq(
          reclamationsTable.statut,
          parsed.data.statut as "ouverte" | "en_cours" | "resolue" | "fermee"
        )
      )
    : await baseQuery;

  return res.json(rows.map(mapReclamation));
});

router.post("/reclamations", async (req, res) => {
  const parsed = CreateReclamationBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Données invalides" });
  }

  const inserted = await db
    .insert(reclamationsTable)
    .values({
      clientId: parsed.data.clientId,
      type: parsed.data.type as "fuite" | "facturation" | "coupure" | "qualite" | "autre",
      description: parsed.data.description,
      statut: "ouverte",
    })
    .returning();

  const row = inserted[0];
  const client = await db
    .select()
    .from(clientsTable)
    .where(eq(clientsTable.id, row.clientId))
    .limit(1);

  return res.status(201).json(
    mapReclamation({
      ...row,
      clientNom: client[0]?.nom ?? null,
      clientPrenom: client[0]?.prenom ?? null,
      numeroAbonnement: client[0]?.numeroAbonnement ?? null,
    })
  );
});

router.patch("/reclamations/:id", async (req, res) => {
  const paramsParsed = UpdateReclamationParams.safeParse(req.params);
  const bodyParsed = UpdateReclamationBody.safeParse(req.body);

  if (!paramsParsed.success || !bodyParsed.success) {
    return res.status(400).json({ error: "Données invalides" });
  }

  const updateData: Record<string, unknown> = {};
  if (bodyParsed.data.statut !== undefined) updateData.statut = bodyParsed.data.statut;
  if (bodyParsed.data.dateResolution !== undefined)
    updateData.dateResolution = new Date(bodyParsed.data.dateResolution);

  const updated = await db
    .update(reclamationsTable)
    .set(updateData)
    .where(eq(reclamationsTable.id, paramsParsed.data.id))
    .returning();

  if (updated.length === 0) {
    return res.status(404).json({ error: "Réclamation non trouvée" });
  }

  const row = updated[0];
  const client = await db
    .select()
    .from(clientsTable)
    .where(eq(clientsTable.id, row.clientId))
    .limit(1);

  return res.json(
    mapReclamation({
      ...row,
      clientNom: client[0]?.nom ?? null,
      clientPrenom: client[0]?.prenom ?? null,
      numeroAbonnement: client[0]?.numeroAbonnement ?? null,
    })
  );
});

export default router;
