import { Router } from "express";
import { eq, ilike, or, and } from "drizzle-orm";
import { db, clientsTable } from "@workspace/db";
import {
  ListClientsQueryParams,
  CreateClientBody,
  GetClientParams,
  UpdateClientParams,
  UpdateClientBody,
  DeleteClientParams,
} from "@workspace/api-zod";

const router = Router();

let abonnementCounter = 0;

function generateNumeroAbonnement(): string {
  abonnementCounter++;
  const year = new Date().getFullYear();
  return `RGD-${year}-${String(abonnementCounter).padStart(5, "0")}`;
}

router.get("/clients", async (req, res) => {
  const parsed = ListClientsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Paramètres invalides" });
  }
  const { search, statut } = parsed.data;

  const conditions = [];
  if (statut) {
    conditions.push(eq(clientsTable.statut, statut as "actif" | "inactif" | "suspendu"));
  }
  if (search) {
    conditions.push(
      or(
        ilike(clientsTable.nom, `%${search}%`),
        ilike(clientsTable.prenom, `%${search}%`),
        ilike(clientsTable.telephone, `%${search}%`),
        ilike(clientsTable.numeroAbonnement, `%${search}%`),
        ilike(clientsTable.adresse, `%${search}%`)
      )
    );
  }

  const clients =
    conditions.length > 0
      ? await db.select().from(clientsTable).where(and(...conditions))
      : await db.select().from(clientsTable);

  return res.json(
    clients.map((c) => ({
      ...c,
      dateInscription: c.dateInscription.toISOString(),
    }))
  );
});

router.post("/clients", async (req, res) => {
  const parsed = CreateClientBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Données invalides" });
  }

  const existing = await db.select().from(clientsTable).limit(1);
  abonnementCounter = existing.length;

  const client = await db
    .insert(clientsTable)
    .values({
      ...parsed.data,
      statut: (parsed.data.statut as "actif" | "inactif" | "suspendu") ?? "actif",
      numeroAbonnement: generateNumeroAbonnement(),
    })
    .returning();

  return res.status(201).json({
    ...client[0],
    dateInscription: client[0].dateInscription.toISOString(),
  });
});

router.get("/clients/:id", async (req, res) => {
  const parsed = GetClientParams.safeParse(req.params);
  if (!parsed.success) {
    return res.status(400).json({ error: "ID invalide" });
  }

  const client = await db
    .select()
    .from(clientsTable)
    .where(eq(clientsTable.id, parsed.data.id))
    .limit(1);

  if (client.length === 0) {
    return res.status(404).json({ error: "Client non trouvé" });
  }

  return res.json({
    ...client[0],
    dateInscription: client[0].dateInscription.toISOString(),
  });
});

router.patch("/clients/:id", async (req, res) => {
  const paramsParsed = UpdateClientParams.safeParse(req.params);
  const bodyParsed = UpdateClientBody.safeParse(req.body);

  if (!paramsParsed.success || !bodyParsed.success) {
    return res.status(400).json({ error: "Données invalides" });
  }

  const updated = await db
    .update(clientsTable)
    .set({
      ...bodyParsed.data,
      statut: bodyParsed.data.statut as "actif" | "inactif" | "suspendu" | undefined,
    })
    .where(eq(clientsTable.id, paramsParsed.data.id))
    .returning();

  if (updated.length === 0) {
    return res.status(404).json({ error: "Client non trouvé" });
  }

  return res.json({
    ...updated[0],
    dateInscription: updated[0].dateInscription.toISOString(),
  });
});

router.delete("/clients/:id", async (req, res) => {
  const parsed = DeleteClientParams.safeParse(req.params);
  if (!parsed.success) {
    return res.status(400).json({ error: "ID invalide" });
  }

  await db.delete(clientsTable).where(eq(clientsTable.id, parsed.data.id));
  return res.status(204).send();
});

export default router;
